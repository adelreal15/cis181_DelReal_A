const yearElement = document.querySelector("#year");
const menuButton = document.querySelector(".menu-toggle");
const navigation = document.querySelector(".site-nav");
const contactForm = document.querySelector("#contactForm");
const formStatus = document.querySelector("#formStatus");

if (yearElement) {
  yearElement.textContent = new Date().getFullYear();
}

if (menuButton && navigation) {
  menuButton.addEventListener("click", () => {
    const isOpen = navigation.classList.toggle("open");
    menuButton.setAttribute("aria-expanded", String(isOpen));
  });
}

if (contactForm && formStatus) {
  contactForm.addEventListener("submit", (event) => {
    event.preventDefault();
    formStatus.textContent = "Thank you. Your message is ready to send once this form is connected to an email service.";
    contactForm.reset();
  });
}
